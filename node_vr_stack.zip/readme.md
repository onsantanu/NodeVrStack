#NodeVrStack
A folder structure to write Rest API with version controlling features.


# Running Process
This structure is compatible to run the node server in multi-core of a machine.
#
If you don't want to run the server as multi-core the change the value of "RUNNING_TYPE" from **multi** to **single** in .env file.
 
